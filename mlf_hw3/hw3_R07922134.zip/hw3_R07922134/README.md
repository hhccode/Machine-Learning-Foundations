# Machine Learning Foundation Hw3

使用 Python3 來實作，並利用 python 套件 `matplotlib` 來畫出 Ein 和 Eout 變化的折線圖。

## Prerequisites

```
Python: 3.6.5
matplotlib: 2.2.2
numpy: 1.14.3
```

## Execute

```
python3 hw3.py
```

## Result

### Question3

會產生出折線圖，縱軸為 Ein 的值，橫軸為 iteration 次數。
其中 Gradient descent 的 learning rate 為 `0.01`，而 SGD 的 learning rate 為 `0.001`。
![](https://i.imgur.com/M56Gr4l.png)
### Question4

會產生出折線圖，縱軸為 Eout 的值，橫軸為 iteration 次數。
其中 Gradient descent 的 learning rate 為 `0.01`，而 SGD 的 learning rate 為 `0.001`。
![](https://i.imgur.com/jvQ0yLw.png)


## Find out

### Question3

Gradient descent 所選出的 w 可以使 Ein 有效的下降，而 SGD 因為 learning rate 相較於 Gradient descent 小，且具有「隨機」的性質，所以幾乎都沒有學到東西，使得 Ein 幾乎沒有產生變化。

### Question4

在 Eout 上的表現和在 Ein 上類似，但普遍還是滿足「Ein < Eout」。
Gradient descent 所選出的 w 可以使 Eout 有效的下降，而 SGD 因為 learning rate 相較於 Gradient descent 小，且具有「隨機」的性質，所以幾乎都沒有學到東西，使得 Eout 幾乎沒有產生變化。

